// enableValidation({
//     formSelector: '.popup__form',
//     inputSelector: '.popup__input',
//     submitButtonSelector: '.popup__button',
//     inactiveButtonClass: 'popup__button_disabled',
//     inputErrorClass: 'popup__input_type_error',
//     errorClass: 'popup__error_visible'
// });

// const buttonSubmitAddPlace = popupCard.querySelector('.popup__submit-button');
// const buttonSubmitEditProfile = popupProfile.querySelector('.popup__submit-button');

const buttonSubmit = document.querySelectorAll('.popup__submit-button');


const cardForm = popupCard.querySelector('.popup__form');
const profileForm = popupProfile.querySelector('.popup__form');

function enableValidation(form) {
    const inputs = Array.from(form.querySelectorAll('.popup__input'));

    inputs.forEach((input) => {
        input.addEventListener('input', () => handleInputValidity(input, form));
    });
}

function handleInputValidity(input, form) {
    // handleSubmitButton(form);
    const fieldset = input.closest('.popup__fieldset');
    const errorBlock = fieldset.querySelector('.popup__input-error');

    errorBlock.classList.remove('popup__input-error_active')

    if (!input.validity.valid) {
        errorBlock.textContent = input.validationMessage;
        errorBlock.classList.add('popup__input-error_active');
        // handleSubmitButton(form);
    }
}

//     function handleSubmitButton(form) {
//     if (form.checkValidity()) {
//         buttonSubmitAddPlace.classList.remove('popup__submit-button_disabled');
//     }
//     else {
//         buttonSubmitAddPlace.classList.add('popup__submit-button_disabled');
//     }
// }

enableValidation(cardForm);
enableValidation(profileForm); 
